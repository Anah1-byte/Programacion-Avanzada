package Punto_Venta;

import java.util.Objects;

public class Cproducto implements Iproductos{
	
	private String id, producto, precio;
	protected String cantidad;

	public String getId() {
		return this.id;
	}
	
	public String getProducto() {
		return this.producto;
	}
	
	public String getPrecio() {
		return this.precio;
	}
	
	public String getCantidad() {
		return this.cantidad;
	}
	
	public void setId(String id) {
		this.id = id;
	}


	public void setProducto(String producto) {
		this.producto = producto;
	}


	public void setPrecio(String precio) {
		this.precio = precio;
	}


	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}
	
	public String subTotal() {
		double subtotal = 0;
		subtotal =  Double.parseDouble(this.getPrecio()) * Double.parseDouble(this.getCantidad());
			return String.valueOf(subtotal);
	}
	
	//public String toStringTicket() {
		//return this.toString() + String.format("%1$-" + 10 + "s",this.subTotal());
	//}

	public String toString() {
		String codigo = String.format("%1$-" + 5 + "s",this.getId());
		String producto = String.format("%1$-" + 30 + "s",this.getProducto());
		String precio = String.format("%1$-" + 10 + "s",this.getPrecio());
		String cantidad  = String.format("%1$-" + 10 + "s",this.getCantidad());
		String cadena = codigo.concat(producto + precio + cantidad);
		return cadena;
	}
	
	public Cproducto ( String id, String producto, String precio, String cantidad) {
		super();
		this.id = id;
		this.producto = producto;
		this.precio = precio;
		this.cantidad = cantidad;
		
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cproducto other = (Cproducto) obj;
		return Objects.equals(id, other.id);
}
}