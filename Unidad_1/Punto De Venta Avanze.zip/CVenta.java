package Punto_Venta;

import java.io.IOException;
import java.util.Objects;
import java.util.ArrayList;

public class CVenta extends Cproducto {
	private ArrayList<Cproducto> productosDelTicket;
	
	String idticket;
	String fecha;
	String hora;

	public CVenta(String id, String producto, String precio, String cantidad) {
		super(id, producto, precio, cantidad);
		// TODO Auto-generated constructor stub
		this.productosDelTicket = new ArrayList<>(); // Inicializamos la lista de productos
	}
	
	public CVenta()
	{
		super("","", "", "");
		this.productosDelTicket = new ArrayList<>();
		
	}

	public String getIdticket() {
		return idticket;
	}

	public void setIdticket(String idticket) {
		this.idticket = idticket;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash (idticket,this.getId());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (!(obj instanceof CVenta))
			return false;
		CVenta other = (CVenta) obj;
		return Objects.equals(this.getId(), other.getId()) && Objects.equals(idticket, other.idticket);
	}
	
	@Override
	public String toString() {
		String codigo = String.format("%1$-" + 5 + "s", this.getId());
		String producto =String.format("%1$-" + 30 + "s", this.getProducto()); 
		String precio = String.format("%1$-" + 10 + "s", this.getPrecio());
		String cantidad =String.format("%1$-" + 10 + "s", this.getCantidad()); 
		String fecha =String.format("%1$-" + 10 + "s", this.getFecha());
		String hora =String.format("%1$-" + 10 + "s", this.getHora());
		String idticket =String.format("%1$-" + 10 + "s", this.getIdticket());
		String cadena = codigo.concat(idticket + fecha + hora + producto + precio + cantidad); 
		return cadena; 
	}
	
	public ArrayList<Cproducto> getProductosDelTicket() {
	    if (productosDelTicket == null) {
	        productosDelTicket = new ArrayList<>(); // Inicializa la lista si es null
	    }
	    return productosDelTicket;
	}
	 
	public void AgregarProducto(Lista<Cproducto> vproductos, CVenta vticket) throws IOException {
	    String codigoProducto = Libreria.Leer("Introduce el código del producto a agregar:");
	    Cproducto producto = vproductos.obtener(new Cproducto(codigoProducto, "", "", ""));
	    
	    if (producto != null) {
	    	vticket.getProductosDelTicket().add(producto); // Para agregar un producto // Ahora 'getProducto()' devuelve la lista correctamente
	        System.out.println("Producto agregado: " + producto.toString());
	    } else {
	        System.out.println("Producto no encontrado.");
	    }
	}

	
	public void Eliminar(Lista<Cproducto> vproductos, CVenta vticket) throws IOException {
	    String codigoProducto = Libreria.Leer("Introduce el código del producto a eliminar:");
	    Cproducto producto = vproductos.obtener(new Cproducto(codigoProducto, "", "", ""));
	    
	    if (producto != null) {
            boolean eliminado = vticket.getProductosDelTicket().remove(producto); // Elimina el producto del ticket
            if (eliminado) {
                System.out.println("Producto eliminado: " + producto.toString());
            } else {
                System.out.println("El producto no está en el ticket.");
            }
        } else {
            System.out.println("Producto no encontrado.");
        }
	}

	public void Pagar(CVenta vticket, ArrayList<CVenta> ventas) throws IOException {
	    double total = 0;
	    
	    // Calcula el total de la venta
	    for (Cproducto producto : vticket.getProductosDelTicket()) {
	        total += Double.parseDouble(producto.getPrecio()) * Integer.parseInt(producto.getCantidad());
	    }

	    // Pide el monto al usuario
	    String monto = Libreria.Leer("Total: " + total + ". Ingresa el monto:");
	    
	    // Verifica si el monto ingresado es válido
	    if (Libreria.EvaluarNumerico(monto, 2)) {
	        double pago = Double.parseDouble(monto);
	        
	        if (pago >= total) {
	            System.out.println("Pago realizado con éxito.");
	            ventas.add(vticket); // Agrega la venta al historial
	        } else {
	            System.out.println("Pago insuficiente.");
	        }
	    } else {
	        System.out.println("Monto no válido.");
	    }
	}

}
