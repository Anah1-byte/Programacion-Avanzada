package Punto_Venta;

import java.util.Scanner;

public class Inicio {

    // Método para gestionar el inicio de sesión y asignar roles
    public static String iniciarSesion() {
        Scanner scanner = new Scanner(System.in); // Crear el objeto Scanner para leer la entrada del usuario

        // Credenciales predefinidas para el inicio de sesión y roles asociados
        String usuarioAdmin = "admin";
        String contrasenaAdmin = "12345";
        String rolAdmin = "Administrador";

        String usuarioCajero = "cajero";
        String contrasenaCajero = "67890";
        String rolCajero = "Cajero";

        // Solicitar el nombre de usuario
        System.out.print("Ingrese el nombre de usuario: ");
        String usuario = scanner.nextLine();

        // Solicitar la contraseña
        System.out.print("Ingrese la contraseña: ");
        String contrasena = scanner.nextLine();

        // Verificar las credenciales y asignar el rol correspondiente
        if (usuario.equals(usuarioAdmin) && contrasena.equals(contrasenaAdmin)) {
            System.out.println("Inicio de sesión exitoso. Rol: " + rolAdmin);
            return rolAdmin; // Retorna el rol de Administrador
        } else if (usuario.equals(usuarioCajero) && contrasena.equals(contrasenaCajero)) {
            System.out.println("Inicio de sesión exitoso. Rol: " + rolCajero);
            return rolCajero; // Retorna el rol de Cajero
        } else {
            System.out.println("Credenciales incorrectas. Intente nuevamente.");
            return null; // Retorna null si las credenciales son incorrectas
        }
    }

    // Método principal para probar el inicio de sesión
    public static void main(String[] args) {
        String rol = iniciarSesion(); // Llama al método de inicio de sesión

        if (rol != null) {
            // Aquí puedes agregar lógica basada en el rol del usuario
            switch (rol) {
                case "Administrador":
                    System.out.println("Acceso completo al sistema.");
                    // Lógica para el administrador
                    break;
                case "Cajero":
                    System.out.println("Acceso limitado al sistema.");
                    // Lógica para el cajero
                    break;
                default:
                    System.out.println("Rol no reconocido.");
                    break;
            }
        } else {
            System.out.println("No se pudo iniciar sesión.");
        }
    }
}