package Punto_Venta;

public interface Iproductos {

	
	public String getId();
	public String getProducto();
	public String getPrecio();
	public String getCantidad();
	public void setId(String id);
	public void setProducto(String producto);
	public void setPrecio(String precio);
	public void setCantidad(String cantidad);
}
