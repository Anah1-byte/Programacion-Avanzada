package Punto_Venta;

import java.io.IOException;
import java.util.ArrayList;

import Punto_Venta.CVenta;
import Punto_Venta.Cproducto;
import Punto_Venta.Cticket;
import Punto_Venta.Lista;
import Punto_Venta.Libreria;

public class CMenuPuntoVenta {

	public  CMenuPuntoVenta (String idticket,Lista<Cproducto> vproductos, ArrayList<CVenta> ventas) throws IOException 
	{ 
		  String opcion = "0";
		    Boolean pago = false;
		    String fechadia = Libreria.Fecha();
		    idticket = Libreria.IdTicketSiguiente(idticket);
		    Cticket Vticket = new Cticket(idticket, fechadia, "00:00");
		    CVenta cventa = new CVenta();
		 
 
	opcion="";
	do {
        String membrete = "Fecha del Dia " + fechadia + " Ticket No " + idticket;
        membrete = membrete + "\n-----------------------------------------------------\n";
        String Tickettexto = Vticket.MostrarTicket(Vticket).trim();

        if (!Tickettexto.trim().isEmpty()) {
            membrete = membrete + "\n" + Tickettexto + "\n";
        }	
	
        ArrayList <String> datosmenu = new ArrayList ();
			datosmenu.add("1.-Agregar");
			datosmenu.add("2.-Eliminar");
			datosmenu.add("3.-Listado");
			datosmenu.add("4.-Pagar");
			datosmenu.add("5.-Salida");
			String opcion1 = "0";
			
			do {
			opcion1 = Libreria.DesplegarMenu("\n Menu de Punto de Venta",datosmenu); 
			if (opcion1 == null) 
				System.out.println("dato incorrecto introducido"); 
			else 
				switch (opcion1) 
				{ 
				case "1":  cventa.AgregarProducto(vproductos, cventa); break; 
				case "2": cventa.Eliminar(vproductos, cventa);
                break;
	       case "3": // Mostrar el ticket actual
               if (Libreria.ObtenerUltimaPosicion(ventas) > -1) {
                   System.out.println(Vticket.MostrarTicket(Vticket));
               }
               break;
				case "4": 
					// Mostrar el ticket y procesar el pago
                    System.out.println(Vticket.MostrarTicket(Vticket).trim());
                    cventa.Pagar(cventa, ventas); // Llamar al método Pagar de CVenta
                    pago = true;
                    opcion1 = "5"; // Salir del menú después de pagar
                    break;
				case "5": 
					// Salir del sistema
                    System.out.println("Salida del Sistema");
                    if (!pago) {
                        System.out.println("No se pagó el ticket");
                        System.out.println("Eliminando ticket " + idticket);
                        // Aquí puedes agregar lógica para eliminar el ticket si no se pagó
                    }
                    break;
                default:
                    System.out.println("No existe esta opción"); break;
            }
        } while (opcion1.compareTo("5") != 0);
} while (true);

}
}

	

