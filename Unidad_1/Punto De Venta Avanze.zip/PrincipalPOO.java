package Punto_Venta;

import java.io.IOException;
import java.util.ArrayList;

public class PrincipalPOO {

	static Lista <Cproducto> productos;
	
	static String ventas[][];
	static int tamventas = 100;
	static String fecha;
	
	public static Lista <Cproducto> CargarProductos(){
		Lista <Cproducto> producto = new Lista();
		
		producto.insertar(new Cproducto("001","Arroz 1Kg", "35","10"));
		producto.insertar(new Cproducto("002","Azucar 1Kg", "25","10"));
		producto.insertar(new Cproducto("003","Harina 1Kg", "28","10"));
		producto.insertar(new Cproducto("004","Aceite 1L", "30","10"));
		producto.insertar(new Cproducto("005","Leche 1L", "35","10"));
		producto.insertar(new Cproducto("006","Huevos 12 unidades", "45","10"));
		producto.insertar(new Cproducto("007","Fideos 500g", "20","10"));
		producto.insertar(new Cproducto("008","Sal 1Kg", "15","10"));
		producto.insertar(new Cproducto("009","Pasta de tomate 400g", "25","10"));
		producto.insertar(new Cproducto("010","Atun lata 170g", "35","10"));
		
		return producto;
	}
	

	public static void MenuPrincipal(Lista<Cproducto> vproductos) throws IOException
	{
		ArrayList<String> datosmenuprincipal = new ArrayList();
		datosmenuprincipal.add("1.-Productos");
		datosmenuprincipal.add("2.-Punto de Venta");
		datosmenuprincipal.add("3.-Inventario");
		datosmenuprincipal.add("4.-Ventas");
		datosmenuprincipal.add("5.-Salida");
		String opcion = "0";
		String idticket;
	
		do
		{
			//idticket = ObtenerUltimoValorVentas(vventas);
			opcion = Libreria.DesplegarMenu("Menu de punto de Tienda de Abarrotes la Pequeñita", datosmenuprincipal);
			
			if(opcion == null)
				System.out.println("opcion incorrecta");
			else 
				switch (opcion)
				{
				//falta adecuar el idticket que revise ventas y si esta vacio sea 000 si no el ultimo del arreglo
				case "1": CMenuProductos menuproductos = new CMenuProductos (vproductos); break;
				case "2": CMenuPuntoVenta puntoventa = new CMenuPuntoVenta ( "", vproductos, null); break;
				case "3": CMenuInventario inventario = new CMenuInventario (vproductos); break;
				case "4": System.out.println("ventas");; break;
				case "5": 
					System.out.println("Salida del Sistema"); break;
					default: System.out.println("No existe esta opcion"); break;
				}
		}
		while  (opcion.compareTo("5") !=0 );
	}
	
	//implementar en pseint 
	public static String ObtenerUltimoValorVentas(String [][] ventas) {
		String ultimovalor = "000";
		for (int i = ventas.length - 1; i >= 0; i--) {
			if (ventas[i][0] != null && !ventas[i][0].isEmpty()) {
				ultimovalor= ventas[i][0];
				break;
			}
		}
		return ultimovalor;
	}
	
	public static void main(String[] args) throws IOException {
        try {
            // Verificar inicio de sesión usando la clase Inicio
        	 String rol = Inicio.iniciarSesion(); // Iniciar sesión y obtener el rol

             if (rol == null) {
                 System.out.println("No se pudo iniciar sesión. Saliendo del sistema.");
                 return;
             }

             // Lógica basada en el rol
             if (rol.equals("Administrador")) {
                 System.out.println("Bienvenido, Administrador. Acceso completo al sistema.");
                 // Lógica para el administrador
             } else if (rol.equals("Cajero")) {
                 System.out.println("Bienvenido, Cajero. Acceso limitado al sistema.");
                 // Lógica para el cajero
             }

            productos = CargarProductos();
        } catch (Exception e) {
            e.printStackTrace();
        }
        MenuPrincipal(productos);
    }

}
