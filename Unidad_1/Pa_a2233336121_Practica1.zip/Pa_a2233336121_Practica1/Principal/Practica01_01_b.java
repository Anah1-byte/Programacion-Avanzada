package Principal;

import java.awt.EventQueue;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

class Practica01_01_b extends JFrame {
    public Practica01_01_b() {
        setTitle("Practica01_01_b - Contenedores");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel panel1 = new JPanel();
        tabbedPane.addTab("Pestaña 1", panel1);

        JScrollPane scrollPane = new JScrollPane(new JTextArea(10, 30));
        tabbedPane.addTab("Pestaña 2", scrollPane);

        JDesktopPane desktopPane = new JDesktopPane();
        tabbedPane.addTab("Pestaña 3", desktopPane);

        JInternalFrame internalFrame = new JInternalFrame("Internal Frame", true, true, true, true);
        internalFrame.setSize(200, 150);
        internalFrame.setVisible(true);
        desktopPane.add(internalFrame);

        add(tabbedPane);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica01_01_b().setVisible(true));
    }
}
