package Principal;

import Modelo.ModeloMensaje;
import Vista.vistamensaje;
import Controlador.ControladorMensaje;

public class Main {
    public static void main(String[] args) {
        ModeloMensaje modelo = new ModeloMensaje();
        vistamensaje vista = new vistamensaje();
        ControladorMensaje controlador = new ControladorMensaje(modelo, vista);

        vista.setControlador(controlador);
        vista.setVisible(true);
    }
}
