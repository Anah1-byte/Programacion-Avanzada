package Principal;

import Modelo.Insumo;
import Vista.VistaInsumos;
import Controlador.ControladorInsumos;

public class PrincipalInsumos {
    public static void main(String[] args) {
        Insumo modelo = new Insumo();
        VistaInsumos vista = new VistaInsumos();
        ControladorInsumos controlador = new ControladorInsumos(modelo, vista);

        vista.setControlador(controlador);
        vista.setVisible(true);
    }
}
