package Modelo;


public class ModeloMensaje {
    public String obtenerMensaje() {
        return "¡Hola, bienvenido a la práctica de MVC en Java Swing!";
    }
}