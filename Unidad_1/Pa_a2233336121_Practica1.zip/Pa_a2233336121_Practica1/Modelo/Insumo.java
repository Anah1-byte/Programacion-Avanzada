package Modelo;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


import java.util.ArrayList;
import java.util.List;

public class Insumo {
    private List<String> insumos;

    public Insumo() {
        this.insumos = new ArrayList<>();
    }

    public void agregarInsumo(String insumo) {
        insumos.add(insumo);
    }

    public void eliminarInsumo(String insumo) {
        insumos.remove(insumo);
    }

    public List<String> obtenerInsumos() {
        return insumos;
    }

	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}
}