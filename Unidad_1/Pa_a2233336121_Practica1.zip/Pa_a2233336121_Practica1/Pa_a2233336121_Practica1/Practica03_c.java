package Pa_a2233336121_Practica1;

import java.io.IOException;

import javax.swing.SwingUtilities;

class Practica03_c extends Practica03_a {
    private static final String ARCHIVO_DATOS = "insumos.txt";
    
    public Practica03_c() {
        setTitle("Gestión de Insumos con Archivo");
        try {
            listaInsumos.getInsumos().addAll(ArchivoTxt.cargarDatos(ARCHIVO_DATOS));
            actualizarArea();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    void guardarDatos() {
        try {
            ArchivoTxt.guardarDatos(listaInsumos.getInsumos(), ARCHIVO_DATOS);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica03_c().setVisible(true));
    }
}