package Pa_a2233336121_Practica1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import Modelo.Insumo;

class Practica03_a extends JFrame {
    protected ListaInsumos listaInsumos = new ListaInsumos();
    private JTextArea areaProductos;
    
    public Practica03_a() {
        setTitle("Gestión de Insumos");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        
        panel.add(new JLabel("ID:"));
        JTextField tid = new JTextField();
        panel.add(tid);
        
        panel.add(new JLabel("Nombre:"));
        JTextField tnombre = new JTextField();
        panel.add(tnombre);
        
        panel.add(new JLabel("Categoría:"));
        JComboBox<String> comboCategoria = new JComboBox<>(new String[]{"Electrónica", "Hogar", "Alimentos"});
        panel.add(comboCategoria);
        
        JButton agregarBtn = new JButton("Agregar");
        agregarBtn.addActionListener(e -> {
            String id = tid.getText();
            String nombre = tnombre.getText();
            String categoria = (String) comboCategoria.getSelectedItem();
            
            listaInsumos.agregarInsumo(new Insumo());
            actualizarArea();
        });
        
        JButton eliminarBtn = new JButton("Eliminar");
        eliminarBtn.addActionListener(e -> {
            String id = tid.getText();
            listaInsumos.eliminarInsumo(id);
            actualizarArea();
        });
        
        areaProductos = new JTextArea(10, 40);
        
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(areaProductos), BorderLayout.CENTER);
        add(agregarBtn, BorderLayout.WEST);
        add(eliminarBtn, BorderLayout.EAST);
    }
    
    protected void actualizarArea() {
        areaProductos.setText("");
        for (Insumo insumo : listaInsumos.getInsumos()) {
            areaProductos.append(insumo + "\n");
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica03_a().setVisible(true));
    }
}