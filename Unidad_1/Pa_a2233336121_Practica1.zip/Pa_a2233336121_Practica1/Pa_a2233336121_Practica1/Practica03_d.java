package Pa_a2233336121_Practica1;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.SwingUtilities;

class Practica03_d extends Practica03_c {
    public Practica03_d() {
        setTitle("Gestión Automática de Insumos");
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                guardarDatos();
            }
        });
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica03_d().setVisible(true));
    }
}