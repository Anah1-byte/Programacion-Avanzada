package Pa_a2233336121_Practica1;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

class Practica02_a extends JFrame {
    public Practica02_a() {
        setTitle("Practica02_a - JButton");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        JButton button = new JButton("Salir");
        panel.add(button);
        add(panel);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica02_a().setVisible(true));
    }
}
