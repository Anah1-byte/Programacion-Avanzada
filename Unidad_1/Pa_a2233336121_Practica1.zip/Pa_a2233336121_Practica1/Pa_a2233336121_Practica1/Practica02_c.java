package Pa_a2233336121_Practica1;

import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

class Practica02_c extends JFrame {
    public Practica02_c() {
        setTitle("Practica02_c - Entrada de Datos");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        
        panel.add(new JLabel("Nombre:"));
        JTextField textField = new JTextField(10);
        panel.add(textField);
        
        panel.add(new JLabel("Contraseña:"));
        JPasswordField passwordField = new JPasswordField(10);
        panel.add(passwordField);
        
        JButton button = new JButton("Aceptar");
        panel.add(button);
        
        add(panel);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica02_c().setVisible(true));
    }
}
