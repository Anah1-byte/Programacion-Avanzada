package Pa_a2233336121_Practica1;

import java.util.ArrayList;
import java.util.List;

import Modelo.Insumo;

class ListaInsumos {
    private List<Insumo> insumos = new ArrayList<>();
    
    public void agregarInsumo(Insumo insumo) {
        insumos.add(insumo);
    }
    
    public void eliminarInsumo(String id) {
        insumos.removeIf(insumo -> insumo.getId().equals(id));
    }
    
    public List<Insumo> getInsumos() {
        return insumos;
    }
}
