package Pa_a2233336121_Practica1;

import javax.swing.SwingUtilities;

class Practica03_b extends Practica03_a {
    public Practica03_b() {
        setTitle("Gestión de Categorías");
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica03_b().setVisible(true));
    }
}
