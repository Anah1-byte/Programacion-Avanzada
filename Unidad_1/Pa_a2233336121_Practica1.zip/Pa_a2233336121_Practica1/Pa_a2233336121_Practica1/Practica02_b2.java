package Pa_a2233336121_Practica1;

import java.awt.EventQueue;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

class Practica02_b2 extends JFrame {
    public Practica02_b2() {
        setTitle("Practica02_b2 - JButton con Mnemónicos");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        JButton button = new JButton("Salir");
        button.setMnemonic(KeyEvent.VK_S);
        panel.add(button);
        add(panel);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Practica02_b2().setVisible(true));
    }
}
