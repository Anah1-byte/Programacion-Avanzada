package Pa_a2233336121_Practica1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Modelo.Insumo;

class ArchivoTxt {
    public static void guardarDatos(List<Insumo> insumos, String archivo) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            for (Insumo insumo : insumos) {
                bw.write(insumo.toString());
                bw.newLine();
            }
        }
    }
    
    public static List<Insumo> cargarDatos(String archivo) throws IOException {
        List<Insumo> insumos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(", ");
                if (partes.length == 3) {
                    insumos.add(new Insumo());
                }
            }
        }
        return insumos;
    }
}