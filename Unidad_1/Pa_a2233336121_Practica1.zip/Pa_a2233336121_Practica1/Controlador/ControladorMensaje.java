package Controlador;
import Modelo.ModeloMensaje;
import Vista.vistamensaje;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorMensaje implements ActionListener {
    private ModeloMensaje modelo;
    private vistamensaje vista;

    public ControladorMensaje(ModeloMensaje modelo, vistamensaje vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(vista, modelo.obtenerMensaje());
    }
}
