package Controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Modelo.Insumo;
import Vista.VistaInsumos;
import Vista.VistaInsumos;

public class ControladorInsumos implements ActionListener {
    private Insumo modelo;
    private VistaInsumos vista;

    public ControladorInsumos(Insumo modelo, VistaInsumos vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnAgregar()) {
            String insumo = vista.getTxtInsumo().getText();
            modelo.agregarInsumo(insumo);
            actualizarVista();
        } else if (e.getSource() == vista.getBtnEliminar()) {
            String insumo = vista.getTxtInsumo().getText();
            modelo.eliminarInsumo(insumo);
            actualizarVista();
        }
    }

    private void actualizarVista() {
        vista.getAreaInsumos().setText(String.join("\n", modelo.obtenerInsumos()));
    }
}