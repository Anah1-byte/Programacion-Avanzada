package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

import Controlador.ControladorInsumos;

public class VistaInsumos extends JFrame {
    private JTextField txtInsumo;
    private JButton btnAgregar, btnEliminar;
    private JTextArea areaInsumos;

    public VistaInsumos() {
        setTitle("Gestión de Insumos");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        txtInsumo = new JTextField(20);
        btnAgregar = new JButton("Agregar");
        btnEliminar = new JButton("Eliminar");
        areaInsumos = new JTextArea(10, 30);
        areaInsumos.setEditable(false);

        add(txtInsumo);
        add(btnAgregar);
        add(btnEliminar);
        add(new JScrollPane(areaInsumos));
    }

    public void setControlador(ControladorInsumos controlador) {
        btnAgregar.addActionListener((ActionListener) controlador);
        btnEliminar.addActionListener((ActionListener) controlador);
    }

    public JTextField getTxtInsumo() { return txtInsumo; }
    public JTextArea getAreaInsumos() { return areaInsumos; }
    public JButton getBtnAgregar() { return btnAgregar; }
    public JButton getBtnEliminar() { return btnEliminar; }
}
