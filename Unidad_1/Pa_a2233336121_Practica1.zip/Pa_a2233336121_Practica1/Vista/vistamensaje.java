package Vista;
import javax.swing.*;
import java.awt.*;
import Controlador.ControladorMensaje;

public class vistamensaje extends JFrame {
    private JButton botonMostrar;

    public vistamensaje() {
        setTitle("Ejercicio 1 - MVC");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        botonMostrar = new JButton("Mostrar Mensaje");
        add(botonMostrar);
    }

    public void setControlador(ControladorMensaje controlador) {
        botonMostrar.addActionListener(controlador);
    }
}