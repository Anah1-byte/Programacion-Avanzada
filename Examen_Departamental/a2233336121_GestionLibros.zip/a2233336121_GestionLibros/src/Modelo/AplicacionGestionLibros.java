package Modelo;

import Controlador.Categorias;
import Controlador.Controlador;
import Vista.VentanaPrincipal;

public class AplicacionGestionLibros {
	
	 public static void main(String[] args) {
	        javax.swing.SwingUtilities.invokeLater(() -> {
	            VentanaPrincipal vista = new VentanaPrincipal(); // Crear la instancia de la VISTA
	            new Controlador(vista); // Crear el CONTROLADOR de libros, pasando la VISTA
	            new Categorias(vista); // Crear el CONTROLADOR de categorías, pasando la VISTA
	        });
	    }
	}