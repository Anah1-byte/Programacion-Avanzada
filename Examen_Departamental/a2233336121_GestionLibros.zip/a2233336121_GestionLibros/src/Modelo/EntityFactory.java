package Modelo;

public class EntityFactory {
    public static Libro crearLibro(int id, String titulo, String autor, String isbn, Categoria categoria) {
        if(titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("El título no puede estar vacío");
        }
        if(autor == null || autor.trim().isEmpty()) {
            throw new IllegalArgumentException("El autor no puede estar vacío");
        }
        if(isbn == null || isbn.trim().isEmpty()) {
            throw new IllegalArgumentException("El ISBN no puede estar vacío");
        }
        if(categoria == null) {
            throw new IllegalArgumentException("Debe seleccionar una categoría");
        }
        
        return new Libro(id, titulo, autor, isbn, categoria);
    }

    public static Categoria crearCategoria(int id, String nombre, String descripcion) {
        if(nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de categoría no puede estar vacío");
        }
        if(descripcion == null) {
            descripcion = ""; // Descripción puede ser opcional
        }
        
        return new Categoria(id, nombre, descripcion);
    }
}