package Modelo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaJSON implements PersistenciaStrategy {
    private static final String ARCHIVO_CATEGORIAS = "categorias.json";
    private static final String ARCHIVO_LIBROS = "libros.json";
    private final Gson gson;

    public PersistenciaJSON() {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    @Override
    public void guardarCategorias(List<Categoria> categorias) {
        try (FileWriter writer = new FileWriter(ARCHIVO_CATEGORIAS)) {
            gson.toJson(categorias, writer);
        } catch (IOException e) {
            System.err.println("Error al guardar las categorías: " + e.getMessage());
        }
    }

    @Override
    public List<Categoria> cargarCategorias() {
        try (FileReader reader = new FileReader(ARCHIVO_CATEGORIAS)) {
            Type tipoLista = new TypeToken<ArrayList<Categoria>>(){}.getType();
            List<Categoria> categorias = gson.fromJson(reader, tipoLista);
            return categorias == null ? new ArrayList<>() : categorias;
        } catch (IOException e) {
            System.err.println("Error al cargar categorías: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public void guardarLibros(List<Libro> libros) {
        try (FileWriter writer = new FileWriter(ARCHIVO_LIBROS)) {
            gson.toJson(libros, writer);
        } catch (IOException e) {
            System.err.println("Error al guardar libros: " + e.getMessage());
        }
    }

    @Override
    public List<Libro> cargarLibros(List<Categoria> categoriasCargadas) {
        try (FileReader reader = new FileReader(ARCHIVO_LIBROS)) {
            Type tipoLista = new TypeToken<ArrayList<Libro>>(){}.getType();
            List<Libro> libros = gson.fromJson(reader, tipoLista);

            if (libros != null && categoriasCargadas != null) {
                for (Libro libro : libros) {
                    int idCategoria = libro.getCategoria().getIdCategoria();
                    categoriasCargadas.stream()
                        .filter(c -> c.getIdCategoria() == idCategoria)
                        .findFirst()
                        .ifPresent(libro::setCategoria);
                }
            }
            return libros == null ? new ArrayList<>() : libros;
        } catch (IOException e) {
            System.err.println("Error al cargar libros: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}