package Modelo;

import java.util.List;

public interface PersistenciaStrategy {
    void guardarCategorias(List<Categoria> categorias);
    List<Categoria> cargarCategorias();
    void guardarLibros(List<Libro> libros);
    List<Libro> cargarLibros(List<Categoria> categoriasCargadas);
}