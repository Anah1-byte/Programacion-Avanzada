package Modelo;

public interface Observer {
    void actualizar(String mensaje);
    void actualizar(Object dato, String accion);
    void actualizar(String mensaje, String tipo);
}