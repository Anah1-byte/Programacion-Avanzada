package Modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Observable {
    private final List<Observer> observadores;

    public Observable() {
        this.observadores = new ArrayList<>(); // Inicialización segura
    }

    public void agregarObservador(Observer observador) {
        if (observador != null && !observadores.contains(observador)) {
            observadores.add(observador);
        }
    }

    public void eliminarObservador(Observer observador) {
        observadores.remove(observador);
    }

    protected void notificarObservadores(String mensaje, String tipo) {
        Objects.requireNonNull(observadores, "La lista de observadores no está inicializada");
        
        // Creamos una copia para evitar ConcurrentModificationException
        List<Observer> copiaObservadores = new ArrayList<>(observadores);
        
        for (Observer observador : copiaObservadores) {
            try {
                observador.actualizar(mensaje, tipo);
            } catch (Exception e) {
                System.err.println("Error notificando al observador: " + e.getMessage());
            }
        }
    }


	public void notificarObservadores(Object dato, String accion) {
		Objects.requireNonNull(observadores, "La lista de observadores no está inicializada");

		// Creamos una copia para evitar ConcurrentModificationException
		List<Observer> copiaObservadores = new ArrayList<>(observadores);

		for (Observer observador : copiaObservadores) {
			try {
				observador.actualizar(dato, accion);
			} catch (Exception e) {
				System.err.println("Error notificando al observador: " + e.getMessage());
			}
		}
	}
}