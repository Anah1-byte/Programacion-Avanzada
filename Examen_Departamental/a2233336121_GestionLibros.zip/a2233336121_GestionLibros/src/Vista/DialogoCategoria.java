package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Modelo.Categoria;

public class DialogoCategoria extends JDialog {
    private JTextField txtNombre = new JTextField(20);
    private JTextField txtDescripcion = new JTextField(20);
    private JButton btnGuardar = new JButton("Guardar");
    private JButton btnCancelar = new JButton("Cancelar");
    private Categoria categoriaAEditar = null; // Para la edición

    public DialogoCategoria(JFrame parent, String title) {
        super(parent, title, true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(3, 2, 5, 5));

        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Descripción:"));
        add(txtDescripcion);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        add(panelBotones);

        pack();
        setLocationRelativeTo(parent);

        btnCancelar.addActionListener(e -> dispose());
    }

    public void setCategoriaAEditar(Categoria categoria) {
        this.categoriaAEditar = categoria;
        txtNombre.setText(categoria.getNombre());
        txtDescripcion.setText(categoria.getDescripcion());
    }

    public Categoria getNuevaCategoria() {
        return new Categoria(
                categoriaAEditar != null ? categoriaAEditar.getIdCategoria() : -1,
                txtNombre.getText(),
                txtDescripcion.getText()
        );
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }
    
    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtDescripcion() {
        return txtDescripcion;
    }
}