package Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Modelo.Categoria;
import Modelo.Libro;

public class DialogoLibro extends JDialog {
    private JTextField txtTitulo = new JTextField(20);
    private JTextField txtAutor = new JTextField(20);
    private JTextField txtISBN = new JTextField(20);
    private JComboBox<Categoria> comboCategoria = new JComboBox<>();
    private JButton btnGuardar = new JButton("Guardar");
    private JButton btnCancelar = new JButton("Cancelar");
    private Libro libroAEditar = null; // Para la edición

    public DialogoLibro(JFrame parent, String title, List<Categoria> categorias) {
        super(parent, title, true); // El tercer argumento 'true' lo hace modal
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 5, 5)); // 5 filas, 2 columnas, espacios

        add(new JLabel("Título:"));
        add(txtTitulo);
        add(new JLabel("Autor:"));
        add(txtAutor);
        add(new JLabel("ISBN:"));
        add(txtISBN);
        add(new JLabel("Categoría:"));
        for (Categoria categoria : categorias) {
            comboCategoria.addItem(categoria);
        }
        add(comboCategoria);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        add(panelBotones);

        pack();
        setLocationRelativeTo(parent);

        btnCancelar.addActionListener(e -> dispose());
    }

    public void setLibroAEditar(Libro libro) {
        this.libroAEditar = libro;
        txtTitulo.setText(libro.getTitulo());
        txtAutor.setText(libro.getAutor());
        txtISBN.setText(libro.getIsbn());
        comboCategoria.setSelectedItem(libro.getCategoria());
    }

    public Libro getNuevoLibro() {
        Categoria categoriaSeleccionada = (Categoria) comboCategoria.getSelectedItem();
        return new Libro(
                libroAEditar != null ? libroAEditar.getIdLibro() : -1, // -1 indica nuevo libro
                txtTitulo.getText(),
                txtAutor.getText(),
                txtISBN.getText(),
                categoriaSeleccionada
        );
    }


    public JTextField getTxtTitulo() {
        return txtTitulo;
    }

    public JTextField getTxtAutor() {
        return txtAutor;
    }

    public JTextField getTxtISBN() {
        return txtISBN;
    }

    public JComboBox<Categoria> getComboCategoria() {
        return comboCategoria;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }
}