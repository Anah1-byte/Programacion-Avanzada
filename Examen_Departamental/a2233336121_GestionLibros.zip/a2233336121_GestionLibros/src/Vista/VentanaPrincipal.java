package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import Modelo.Libro;
import Modelo.Observer;
import Modelo.Categoria;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class VentanaPrincipal extends JFrame implements Observer {
    // Constantes para configuración
    private static final String TITULO_VENTANA = "Sistema de Gestión de Libros";
    private static final Dimension DIMENSION_VENTANA = new Dimension(900, 600);
    private static final Color COLOR_FONDO_FILAS = new Color(240, 240, 240);
    private static final int ALTURA_FILA = 25;
 // Agrega estas constantes al inicio de la clase
 // Reemplaza las constantes de color al inicio de la clase
    private static final Color COLOR_PRIMARIO = new Color(197, 224, 220); // Azul claro suave
    private static final Color COLOR_SECUNDARIO = new Color(216, 248, 225); // Verde claro muy suave
    private static final Color COLOR_TERCIARIO = new Color(211, 211, 211); // Gris neutro
    private static final Color COLOR_TEXTO = new Color(60, 60, 60); // Gris oscuro para texto
    private static final Font FUENTE_NORMAL = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FUENTE_TITULO = new Font("Segoe UI", Font.BOLD, 14);
    
    // Componentes principales
    private JPanel panelPrincipal;
    private JTabbedPane panelPestañas;
    
    // Componentes para pestaña de libros
    private JPanel panelLibros;
    private JButton btnNuevoLibro;
    private JButton btnEditarLibro;
    private JButton btnEliminarLibro;
    private JTable tablaLibros;
    private DefaultTableModel modeloTablaLibros;
    
    // Componentes para pestaña de categorías
    private JPanel panelCategorias;
    private JButton btnNuevaCategoria;
    private JButton btnEditarCategoria;
    private JButton btnEliminarCategoria;
    private JTable tablaCategorias;
    private DefaultTableModel modeloTablaCategorias;

    public VentanaPrincipal() {
        configurarVentana();
        inicializarComponentes();
        organizarComponentes();
        aplicarEstilos();
        setVisible(true);
    }

    private void configurarVentana() {
        setTitle(TITULO_VENTANA);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(DIMENSION_VENTANA);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(700, 500));
        getContentPane().setBackground(COLOR_SECUNDARIO); // Fondo principal verde claro
    }

    private void inicializarComponentes() {
        panelPrincipal = new JPanel(new BorderLayout());
        panelPestañas = new JTabbedPane();
        
        // Inicializar componentes para libros
        panelLibros = new JPanel(new BorderLayout());
        inicializarComponentesLibros();
        
        // Inicializar componentes para categorías
        panelCategorias = new JPanel(new BorderLayout());
        inicializarComponentesCategorias();
    }

    private void inicializarComponentesLibros() {
        btnNuevoLibro = crearBoton("Nuevo Libro");
        btnEditarLibro = crearBoton("Editar Libro");
        btnEliminarLibro = crearBoton("Eliminar Libro");
        
        modeloTablaLibros = new DefaultTableModel(new Object[]{"ID", "Título", "Autor", "ISBN", "Categoría"}, 0);
        tablaLibros = new JTable(modeloTablaLibros);
        
        configurarTabla(tablaLibros, new int[]{50, 200, 150, 100, 150});
    }

    private void inicializarComponentesCategorias() {
        btnNuevaCategoria = crearBoton("Nueva Categoría");
        btnEditarCategoria = crearBoton("Editar Categoría");
        btnEliminarCategoria = crearBoton("Eliminar Categoría");
        
        modeloTablaCategorias = new DefaultTableModel(new Object[]{"ID", "Nombre", "Descripción"}, 0);
        tablaCategorias = new JTable(modeloTablaCategorias);
        
        configurarTabla(tablaCategorias, new int[]{50, 200, 300});
    }

    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setFocusPainted(false);
        boton.setPreferredSize(new Dimension(160, 35));
        boton.setFont(FUENTE_NORMAL);
        boton.setBackground(COLOR_PRIMARIO); // Azul claro para botones
        boton.setForeground(COLOR_TEXTO); // Texto oscuro
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO.darker(), 1),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        
        // Efecto hover moderno
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                boton.setBackground(COLOR_PRIMARIO.brighter());
                boton.setForeground(Color.WHITE);
            }
            public void mouseExited(MouseEvent evt) {
                boton.setBackground(COLOR_PRIMARIO);
                boton.setForeground(COLOR_TEXTO);
            }
        });
        
        return boton;
    }

    private void configurarTabla(JTable tabla, int[] anchosColumnas) {
        tabla.setRowHeight(ALTURA_FILA);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setShowGrid(false);
        tabla.setIntercellSpacing(new Dimension(0, 0));
        tabla.setAutoCreateRowSorter(true);
        tabla.setFont(FUENTE_NORMAL);
        tabla.getTableHeader().setFont(FUENTE_TITULO);
        tabla.getTableHeader().setBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setForeground(COLOR_TEXTO);
        tabla.setSelectionBackground(COLOR_PRIMARIO.darker());
        tabla.setSelectionForeground(Color.WHITE);
        
        // Renderizado mejorado
        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : COLOR_FONDO_FILAS);
                }
                
                // Alinear contenido
                if (column == 0) { // ID
                    ((JLabel)c).setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    ((JLabel)c).setHorizontalAlignment(SwingConstants.LEFT);
                }
                
                return c;
            }
        });
        
        // Configurar anchos de columnas
        for (int i = 0; i < anchosColumnas.length; i++) {
            tabla.getColumnModel().getColumn(i).setPreferredWidth(anchosColumnas[i]);
        }
    }
    private void organizarComponentes() {
        // Paneles de botones
        JPanel panelBotonesLibros = crearPanelBotones(btnNuevoLibro, btnEditarLibro, btnEliminarLibro);
        JPanel panelBotonesCategorias = crearPanelBotones(btnNuevaCategoria, btnEditarCategoria, btnEliminarCategoria);
        
        // Añadir componentes
        panelLibros.add(panelBotonesLibros, BorderLayout.NORTH);
        panelLibros.add(new JScrollPane(tablaLibros), BorderLayout.CENTER);
        panelLibros.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        panelCategorias.add(panelBotonesCategorias, BorderLayout.NORTH);
        panelCategorias.add(new JScrollPane(tablaCategorias), BorderLayout.CENTER);
        panelCategorias.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Configurar pestañas
        panelPestañas.addTab("Libros", panelLibros);
        panelPestañas.addTab("Categorías", panelCategorias);
        
        // Estilo de pestañas
        panelPestañas.setFont(FUENTE_TITULO);
        panelPestañas.setBackground(COLOR_SECUNDARIO);
        for (int i = 0; i < panelPestañas.getTabCount(); i++) {
            panelPestañas.setBackgroundAt(i, COLOR_SECUNDARIO);
        }
        
        panelPrincipal.add(panelPestañas, BorderLayout.CENTER);
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(panelPrincipal);
    }

    private JPanel crearPanelBotones(JButton... botones) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setBackground(COLOR_SECUNDARIO);
        for (JButton boton : botones) {
            panel.add(boton);
        }
        return panel;
    }

    private void aplicarEstilos() {
        try {
            // Configurar Nimbus Look and Feel con nuestros colores
            UIManager.put("nimbusBase", COLOR_PRIMARIO);
            UIManager.put("nimbusBlueGrey", COLOR_SECUNDARIO);
            UIManager.put("control", COLOR_SECUNDARIO);
            UIManager.put("text", COLOR_TEXTO);
            
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            
            // Configuraciones específicas
            UIManager.put("TabbedPane.background", COLOR_SECUNDARIO);
            UIManager.put("TabbedPane.selected", COLOR_PRIMARIO);
            UIManager.put("Table.background", Color.WHITE);
            UIManager.put("TableHeader.background", COLOR_PRIMARIO);
            
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            try {
                // Fallback a Metal si Nimbus no está disponible
                UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
                UIManager.put("TabbedPane.background", COLOR_SECUNDARIO);
                SwingUtilities.updateComponentTreeUI(this);
            } catch (Exception ex) {
                System.err.println("Error al aplicar estilos");
            }
        }
    }

    // Métodos getter (mantenidos de la versión original)
    public JButton getBtnNuevoLibro() { return btnNuevoLibro; }
    public JButton getBtnEditarLibro() { return btnEditarLibro; }
    public JButton getBtnEliminarLibro() { return btnEliminarLibro; }
    public JTable getTablaLibros() { return tablaLibros; }
    public DefaultTableModel getModeloTablaLibros() { return modeloTablaLibros; }
    public JButton getBtnNuevaCategoria() { return btnNuevaCategoria; }
    public JButton getBtnEditarCategoria() { return btnEditarCategoria; }
    public JButton getBtnEliminarCategoria() { return btnEliminarCategoria; }
    public JTable getTablaCategorias() { return tablaCategorias; }
    public DefaultTableModel getModeloTablaCategorias() { return modeloTablaCategorias; }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal());
    }
    
    @Override
    public void actualizar(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Notificación", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void actualizar(Object dato, String accion) {
        switch (accion) {
            case "INICIO":
                setTitle(getTitle() + " - Sesión activa");
                break;
            case "CREAR":
            case "EDITAR":
            case "ELIMINAR":
                JOptionPane.showMessageDialog(this, dato.toString(), "Operación exitosa", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "ERROR":
                JOptionPane.showMessageDialog(this, dato.toString(), "Error", JOptionPane.ERROR_MESSAGE);
                break;
            default:
                System.out.println("Notificación: " + dato);
        }
    }

    @Override
    public void actualizar(String mensaje, String tipo) {
        SwingUtilities.invokeLater(() -> {
            switch (tipo) {
                case "ERROR":
                    JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "EXITO":
                    JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    System.out.println("Notificación: " + mensaje);
            }
        });
    }

}