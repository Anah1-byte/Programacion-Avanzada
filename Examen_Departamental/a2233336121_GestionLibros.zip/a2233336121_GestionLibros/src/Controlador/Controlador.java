package Controlador;

import Vista.DialogoLibro;
import Vista.VentanaPrincipal;
import Modelo.PersistenciaJSON;
import Modelo.PersistenciaStrategy;
import Modelo.Libro;
import Modelo.Observable;
import Modelo.Observer;
import Modelo.Categoria;
import Modelo.EntityFactory;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.util.ArrayList;
import java.util.List;

public class Controlador {
	   private final VentanaPrincipal vista;
	    private final PersistenciaStrategy persistencia;
	    private final List<Libro> libros;
	    private final List<Categoria> categorias;
	    private DialogoLibro dialogoLibro;
	    private final Observable observable;
	    private final List<Observer> observadores = new ArrayList<>();

	    public Controlador(VentanaPrincipal vista) {
	        // Validación de parámetro
	        if (vista == null) {
	            throw new IllegalArgumentException("La vista no puede ser nula");
	        }
	        
	        this.vista = vista;
	        this.persistencia = new PersistenciaJSON();
	        this.categorias = persistencia.cargarCategorias();
	        this.libros = persistencia.cargarLibros(this.categorias);
	        this.observable = new Observable(); // Inicialización correcta
	        
	        // Registrar la vista como observadora
	        if (vista instanceof Observer) {
	            this.observadores.add((Observer)vista);
	        }else {
	            throw new IllegalStateException("La vista debe implementar Observer");
	        }
	        
	        inicializarVista();
	        agregarListeners();
	    }

	    private void inicializarVista() {
	        cargarLibrosEnTabla();
	        notificar("Sistema de gestión de libros iniciado", "INICIO");
	    }

    private void notificar(String mensaje, String tipo) {
        // Hacemos copia para evitar problemas de concurrencia
        List<Observer> copiaObservadores = new ArrayList<>(observadores);
           // Notificamos a cada observador
        for (Observer observador : copiaObservadores) {
            try {
                observador.actualizar(mensaje, tipo);
            } catch (Exception e) {
                System.err.println("Error notificando al observador: " + e.getMessage());
            }
        }
    }
	private void cargarLibrosEnTabla() {
        DefaultTableModel modeloTabla = vista.getModeloTablaLibros();
        modeloTabla.setRowCount(0);
        for (Libro libro : libros) {
            modeloTabla.addRow(new Object[]{
                libro.getIdLibro(),
                libro.getTitulo(),
                libro.getAutor(),
                libro.getIsbn(),
                libro.getCategoria().getNombre()
            });
        }
    }

    private void agregarListeners() {
        vista.getBtnNuevoLibro().addActionListener(e -> mostrarDialogoNuevoLibro());
        vista.getBtnEditarLibro().addActionListener(e -> mostrarDialogoEditarLibro());
        vista.getBtnEliminarLibro().addActionListener(e -> eliminarLibro());
    }

    private void mostrarDialogoNuevoLibro() {
        dialogoLibro = new DialogoLibro(vista, "Nuevo Libro", categorias);
        dialogoLibro.getBtnGuardar().addActionListener(e -> guardarNuevoLibro(dialogoLibro));
        dialogoLibro.setVisible(true);
    }

    private void guardarNuevoLibro(DialogoLibro dialogo) {
        try {
            Libro nuevoLibro = EntityFactory.crearLibro(
                libros.isEmpty() ? 1 : libros.get(libros.size() - 1).getIdLibro() + 1,
                dialogo.getTxtTitulo().getText(),
                dialogo.getTxtAutor().getText(),
                dialogo.getTxtISBN().getText(),
                (Categoria)dialogo.getComboCategoria().getSelectedItem()
            );
            
            libros.add(nuevoLibro);
            cargarLibrosEnTabla();
            dialogo.dispose();
            guardarDatos();
            notificar("Libro creado: " + nuevoLibro.getTitulo(), "CREAR");
        } catch (IllegalArgumentException e) {
            notificar(e.getMessage(), "ERROR");
        }
    }

    private void mostrarDialogoEditarLibro() {
        int filaSeleccionada = vista.getTablaLibros().getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(vista, "Por favor, seleccione un libro para editar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idLibroSeleccionado = (int) vista.getModeloTablaLibros().getValueAt(filaSeleccionada, 0);
        Libro libroAEditar = libros.stream().filter(libro -> libro.getIdLibro() == idLibroSeleccionado).findFirst().orElse(null);

        if (libroAEditar != null) {
            DialogoLibro dialogoLibro = new DialogoLibro(vista, "Editar Libro", categorias);
            dialogoLibro.setLibroAEditar(libroAEditar);
            dialogoLibro.getBtnGuardar().addActionListener(e -> guardarLibroEditado(dialogoLibro, libroAEditar));
            dialogoLibro.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo encontrar el libro seleccionado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarLibroEditado(DialogoLibro dialogo, Libro libroOriginal) {
        Libro libroEditado = dialogo.getNuevoLibro();
        libroEditado.setIdLibro(libroOriginal.getIdLibro()); // Mantener el ID original
        int index = libros.indexOf(libroOriginal);
        if (index != -1) {
            libros.set(index, libroEditado);
            cargarLibrosEnTabla();
            dialogo.dispose();
            guardarDatos();
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo actualizar el libro.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarLibro() {
        int filaSeleccionada = vista.getTablaLibros().getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(vista, "Por favor, seleccione un libro para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idLibroAEliminar = (int) vista.getModeloTablaLibros().getValueAt(filaSeleccionada, 0);
        Libro libroAEliminar = libros.stream().filter(libro -> libro.getIdLibro() == idLibroAEliminar).findFirst().orElse(null);

        if (libroAEliminar != null) {
            int opcion = JOptionPane.showConfirmDialog(vista, "¿Está seguro de que desea eliminar el libro \"" + libroAEliminar.getTitulo() + "\"?");
            if (opcion == JOptionPane.YES_OPTION) {
                libros.remove(libroAEliminar);
                cargarLibrosEnTabla();
                guardarDatos();
            }
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo encontrar el libro seleccionado para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void guardarDatos() {
        persistencia.guardarCategorias(this.categorias);
        persistencia.guardarLibros(this.libros);
        notificar("Datos guardados correctamente", "GUARDAR");
    }
}