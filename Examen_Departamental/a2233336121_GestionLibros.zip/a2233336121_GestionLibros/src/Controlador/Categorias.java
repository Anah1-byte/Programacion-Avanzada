package Controlador;

import Vista.DialogoCategoria;
import Vista.VentanaPrincipal;
import Modelo.PersistenciaJSON;
import Modelo.PersistenciaStrategy;
import Modelo.Categoria;
import Modelo.EntityFactory;
import Modelo.Libro;
import Modelo.Observable;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Categorias extends Observable {
    private VentanaPrincipal vista;
    private PersistenciaStrategy persistencia;
    private List<Categoria> categorias;
    private DialogoCategoria dialogoCategoria;

    public Categorias(VentanaPrincipal vista) {
        super(); // Asegura la inicialización del Observable
        this.vista = vista;
        this.persistencia = new PersistenciaJSON();
        this.categorias = persistencia.cargarCategorias();
        
        // Verificación antes de agregar observador
        if (vista != null) {
            agregarObservador(vista);
        } else {
            System.err.println("Advertencia: La vista es nula, no se agregará como observador");
        }
        
        inicializarVista();
        agregarListeners();
    }

    private void inicializarVista() {
        cargarCategoriasEnTabla();
        notificarObservadores("Vista de categorías inicializada", "INFO"); // Notificación segura
    }


    private void cargarCategoriasEnTabla() {
        DefaultTableModel modeloTabla = vista.getModeloTablaCategorias();
        modeloTabla.setRowCount(0);
        for (Categoria categoria : categorias) {
            modeloTabla.addRow(new Object[]{
                    categoria.getIdCategoria(),
                    categoria.getNombre(),
                    categoria.getDescripcion()
            });
        }
    }

    private void agregarListeners() {
        vista.getBtnNuevaCategoria().addActionListener(e -> mostrarDialogoNuevaCategoria());
        vista.getBtnEditarCategoria().addActionListener(e -> mostrarDialogoEditarCategoria());
        vista.getBtnEliminarCategoria().addActionListener(e -> eliminarCategoria());
    }

    private void mostrarDialogoNuevaCategoria() {
        dialogoCategoria = new DialogoCategoria(vista, "Nueva Categoría");
        dialogoCategoria.getBtnGuardar().addActionListener(e -> guardarNuevaCategoria(dialogoCategoria));
        dialogoCategoria.setVisible(true);
    }

    private void mostrarDialogoEditarCategoria() {
        int filaSeleccionada = vista.getTablaCategorias().getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(vista, "Por favor, seleccione una categoría para editar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idCategoriaSeleccionada = (int) vista.getModeloTablaCategorias().getValueAt(filaSeleccionada, 0);
        Categoria categoriaAEditar = categorias.stream().filter(categoria -> categoria.getIdCategoria() == idCategoriaSeleccionada).findFirst().orElse(null);

        if (categoriaAEditar != null) {
            dialogoCategoria = new DialogoCategoria(vista, "Editar Categoría");
            dialogoCategoria.setCategoriaAEditar(categoriaAEditar);
            dialogoCategoria.getBtnGuardar().addActionListener(e -> guardarCategoriaEditada(dialogoCategoria, categoriaAEditar));
            dialogoCategoria.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo encontrar la categoría seleccionada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarNuevaCategoria(DialogoCategoria dialogo) {
        try {
            Categoria nuevaCategoria = EntityFactory.crearCategoria(
                categorias.isEmpty() ? 1 : categorias.get(categorias.size() - 1).getIdCategoria() + 1,
                dialogo.getTxtNombre().getText(),
                dialogo.getTxtDescripcion().getText()
            );
            
            categorias.add(nuevaCategoria);
            cargarCategoriasEnTabla();
            dialogo.dispose();
            guardarDatos();
            notificarObservadores("Categoría creada: " + nuevaCategoria.getNombre(), "CREAR");
        } catch (IllegalArgumentException e) {
            notificarObservadores(e.getMessage(), "ERROR");
        }
    }

    private void guardarCategoriaEditada(DialogoCategoria dialogo, Categoria categoriaOriginal) {
        Categoria categoriaEditada = dialogo.getNuevaCategoria();
        categoriaEditada.setIdCategoria(categoriaOriginal.getIdCategoria());
        int index = categorias.indexOf(categoriaOriginal);
        if (index != -1) {
            categorias.set(index, categoriaEditada);
            cargarCategoriasEnTabla();
            dialogo.dispose();
            guardarDatos();
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo actualizar la categoría.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarCategoria() {
        int filaSeleccionada = vista.getTablaCategorias().getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(vista, "Por favor, seleccione una categoría para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idCategoriaAEliminar = (int) vista.getModeloTablaCategorias().getValueAt(filaSeleccionada, 0);
        Categoria categoriaAEliminar = categorias.stream().filter(categoria -> categoria.getIdCategoria() == idCategoriaAEliminar).findFirst().orElse(null);

        if (categoriaAEliminar != null) {
            // Antes de eliminar una categoría, podríamos verificar si hay libros asociados a ella
            // y preguntar al usuario qué hacer (o prevenir la eliminación). Por ahora, lo omitimos.
            int opcion = JOptionPane.showConfirmDialog(vista, "¿Está seguro de que desea eliminar la categoría \"" + categoriaAEliminar.getNombre() + "\"?");
            if (opcion == JOptionPane.YES_OPTION) {
                categorias.remove(categoriaAEliminar);
                cargarCategoriasEnTabla();
                guardarDatos();
            }
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo encontrar la categoría seleccionada para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void guardarDatos() {
        persistencia.guardarCategorias(this.categorias);
        persistencia.guardarLibros(obtenerLibrosActualizados()); // Necesitamos obtener la lista de libros actual
    }

    // Método auxiliar para obtener la lista de libros actual (podría estar en el LibroControlador)
    private List<Libro> obtenerLibrosActualizados() {
        // Por ahora, simplemente devolvemos la lista de libros que ya tenemos cargada.
        // En una implementación más compleja, podríamos necesitar refrescar esta lista.
        return vista.getModeloTablaLibros().getDataVector().stream()
                .map(row -> new Libro(
                        Integer.parseInt(row.get(0).toString()),
                        row.get(1).toString(),
                        row.get(2).toString(),
                        row.get(3).toString(),
                        categorias.stream().filter(c -> c.getNombre().equals(row.get(4).toString())).findFirst().orElse(null)
                ))
                .toList();
        // Nota: Esta forma de obtener los libros de la tabla no es ideal y podría llevar a inconsistencias.
        // Lo mejor sería que el LibroControlador mantuviera su propia lista de libros actualizada.
        // Para simplificar por ahora, lo dejamos así.
    }
}